<?php
// Start session and do the security check as before.
session_start();
if (!isset($_GET['order_id']) || empty(trim($_GET['order_id']))) {
    header('Location: index.html');
    exit();
}

// NEW: Get the filename from the URL for the download link.
$order_id = htmlspecialchars($_GET['order_id']);
$filename = isset($_GET['filename']) ? htmlspecialchars($_GET['filename']) : null;

// Construct the secure download URL
$download_url = null;
if ($filename) {
    $download_url = 'php/download_cv.php?order_id=' . urlencode($order_id) . '&filename=' . urlencode($filename);
}

// Clear the session data
unset($_SESSION['form_data']);
unset($_SESSION['cv_content_html']);
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <!-- META TAGS -->

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>TwigaCV | Thank You for Choosing TwigaCV </title>

    <!-- END META TAGS ==>
    
    <!- Favicon  -->
<link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
<link rel="manifest" href="img/favicon/site.webmanifest">

   <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/verify.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/fontawesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

</head>
<body>


    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand topnav" href="index.html">TwigaCV</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                      <a href="index.html">Home</a>
                    </li>
                    <li>
                        <a href="create.html">CV</a>
                    </li>
                    
                     
                     <li><a href="index.html#udsm">UDSM</a></li>
                    <li><a href="privacy.html">Terms & Privacy</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    </div>
    <!-- /.content-section-a -->
    
  

       <div class="content-section-b">

        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">Thank You for Choosing TwigaCV!</h2>
                    
                    <?php if ($download_url): ?>
                        <!-- This block shows ONLY if a download link is available -->
                        <p class="lead" id="download-message">Your download should start automatically. If it doesn't, please use the button below.</p>
                        
                        <a href="<?php echo $download_url; ?>" id="downloadBtn" class="btn btn-success btn-lg" style="margin-top: 20px; margin-bottom: 20px;">
                            <span class="glyphicon glyphicon-download-alt"></span> Download Your CV Now
                        </a>
                        
                        <p class="lead">A copy of your CV has also been sent to your email. Please check your inbox and spam folder.</p>
                    
                    <?php else: ?>
                        <!-- This block is a fallback if the filename wasn't passed -->
                        <p class="lead">Success! Your CV has been successfully generated and a copy is on its way to your email address. Please be sure to check both your inbox and spam/junk folder.</p>
                    <?php endif; ?>

                </div>
                <div class="col-lg-5 col-sm-6">
                    <img class="img-responsive" src="img/success.png" alt="TwigaCV Success">
                </div>
            </div>
        </div>
    </div>
    
       <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline">
                      <li><a href="#">Home</a></li>
                      <li class="footer-menu-divider">&sdot;</li>
                      <li><a href="create.html">CV</a></li>
                      
                     
                      <li class="footer-menu-divider">&sdot;</li>
                      <li><a href="https://instagram.com/twigacv">Instagram</a></li>
                      <li class="footer-menu-divider">&sdot;</li>
                      <li><a href="https://wa.me/+255744400401">WhatsApp</a></li>
                      <li class="footer-menu-divider">&sdot;</li>
                      <li><a href="privacy.html">Terms & Privacy</a></li>
                    </ul>
                    <p class="copyright text-muted small">Copyright &copy; TwigaCV Tanzania <span id="currentYear"></span>. All Rights Reserved. Made with &#x1F499; by  <a href="https://linkedin.com/in/isaiahnyalali">Isaiah Nyalali</a></p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <?php if ($download_url): ?>
    <script>
        // This JavaScript will automatically trigger the download
        document.addEventListener('DOMContentLoaded', function() {
            // Wait a moment for the user to read the page
            setTimeout(function() {
                // Method 1: The simplest way
                // window.location.href = document.getElementById('downloadBtn').href;

                // Method 2: A more robust way that doesn't navigate away
                const downloadLink = document.createElement('a');
                downloadLink.href = '<?php echo $download_url; ?>';
                downloadLink.download = '<?php echo $filename; ?>'; // Suggest a filename
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);
                
                // Update the message after triggering the download
                document.getElementById('download-message').innerText = 'Your CV download has started!';

            }, 1500); // 1.5 second delay
        });
    </script>
    <?php endif; ?>
</body>
</html>