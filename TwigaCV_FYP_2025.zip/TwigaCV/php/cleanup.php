<?php
// --- TwigaCV Cleanup Cron Script ---
// This script is designed to be run automatically by a cron job.

// Set the timezone to ensure correct date/time comparisons
date_default_timezone_set('Africa/Dar_es_Salaam');

// --- CONFIGURATION ---
// Define how old a file must be (in seconds) before it gets deleted.

// Temporary order files: Keep for 24 hours (86400 seconds). 
// This gives users ample time to use the direct download link on the success page.
$temp_order_age_limit_seconds = 86400; 

// Exported PDFs: Keep for 60 days (5184000 seconds).
// These are your backups. You can set this to a very large number if you want to keep them indefinitely.
$cv_export_age_limit_seconds = 5184000;


// Define the directories to clean
$temp_orders_dir = __DIR__ . '/temp_orders/';
$cv_exports_dir = __DIR__ . '/cv_exports/';

echo "--- Starting TwigaCV Cleanup Job at " . date('Y-m-d H:i:s') . " ---\n\n";


// --- Function to perform cleanup on a directory ---
function clean_directory($directory_path, $age_limit_seconds, $file_extension) {
    echo "Scanning directory: " . $directory_path . "\n";
    echo "Deleting " . $file_extension . " files older than " . ($age_limit_seconds / 3600) . " hours...\n";

    if (!is_dir($directory_path)) {
        echo " -> Directory not found. Skipping.\n\n";
        return;
    }

    // Get all files matching the extension
    $files = glob($directory_path . '*.' . $file_extension);
    
    $deleted_count = 0;
    $scanned_count = count($files);
    $current_time = time();

    foreach ($files as $file) {
        // Check if the file's modification time is older than our limit
        if (is_file($file) && ($current_time - filemtime($file) >= $age_limit_seconds)) {
            if (unlink($file)) {
                echo " -> Deleted: " . basename($file) . "\n";
                $deleted_count++;
            } else {
                echo " -> ERROR: Failed to delete " . basename($file) . "\n";
            }
        }
    }
    echo " -> Scanned " . $scanned_count . " files. Deleted " . $deleted_count . " old files.\n\n";
}


// --- Execute Cleanup ---
clean_directory($temp_orders_dir, $temp_order_age_limit_seconds, 'json');
clean_directory($cv_exports_dir, $cv_export_age_limit_seconds, 'pdf');


echo "--- Cleanup Job Finished at " . date('Y-m-d H:i:s') . " ---\n";
?>