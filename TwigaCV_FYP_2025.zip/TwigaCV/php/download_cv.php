<?php
// --- php/download_cv.php ---

// This script securely serves a PDF for download after verifying the order.

// 1. Get the parameters from the URL
$order_id = $_GET['order_id'] ?? null;
$filename = $_GET['filename'] ?? null;

if (!$order_id || !$filename) {
    http_response_code(400);
    die('Error: Missing required parameters.');
}

// 2. Define the file paths
$orderFilePath = __DIR__ . '/temp_orders/' . $order_id . '.json';
$pdfFilePath = __DIR__ . '/cv_exports/' . $filename;

// 3. Security Check: Verify that BOTH the order file and the PDF file exist.
// This prevents someone from guessing filenames. They must have a valid, recent order_id.
if (!file_exists($orderFilePath) || !file_exists($pdfFilePath)) {
    http_response_code(404);
    die('Error: Invalid download link or the link has expired. Please check the CV sent to your email.');
}

// 4. If all checks pass, serve the file for download.

// Set headers to force download
header('Content-Description: File Transfer');
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . basename($pdfFilePath) . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($pdfFilePath));

// Clean output buffer and read the file to the browser
ob_clean();
flush();
readfile($pdfFilePath);
exit;

?>