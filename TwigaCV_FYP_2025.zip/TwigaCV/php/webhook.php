<?php
// Set up error logging for robust debugging
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/webhook_errors.log');
error_reporting(E_ALL);

// Load the DomPDF library autoloader from your root dompdf/ folder
require_once __DIR__ . '/../dompdf/autoload.inc.php';

// Include our other application helper scripts
require_once __DIR__ . '/mail.php';
require_once __DIR__ . '/sms.php';
require_once __DIR__ . '/download.php';

// --- Helper Functions ---
function log_message($message) {
    $timestamp = date("Y-m-d H:i:s");
    $logDir = __DIR__ . '/logs/';
    // Create the logs directory if it doesn't exist to prevent errors
    if (!is_dir($logDir)) {
        mkdir($logDir, 0775, true);
    }
    file_put_contents($logDir . 'webhook.log', "[$timestamp] $message\n", FILE_APPEND);
}

function update_google_sheet($data) {
    $url = 'SheetDB URL';
    $options = [
        'http' => [
            'header'  => "Content-type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode(['data' => [$data]]) // SheetDB API expects the data to be wrapped in a 'data' array
        ]
    ];
    $context  = stream_context_create($options);
    // Use a try-catch block for robustness in case the SheetDB API is down
    try {
        $result = file_get_contents($url, false, $context);
        return $result;
    } catch (Exception $e) {
        log_message("Google Sheet API Error: " . $e->getMessage());
        return false;
    }
}

// --- Main Webhook Logic ---
log_message("Webhook received a request.");
$payload = file_get_contents('php://input');
log_message("Payload: " . $payload);

$data = json_decode($payload, true);
// Check if the JSON payload is valid
if (json_last_error() !== JSON_ERROR_NONE) {
    log_message("FATAL: Could not decode JSON payload. Error: " . json_last_error_msg());
    http_response_code(400); // Bad Request
    exit;
}

$tempFileDir = __DIR__ . '/temp_orders/';

// Extract key info from the ZenoPay webhook payload
$order_id = $data['order_id'] ?? null;
$payment_status = $data['payment_status'] ?? null;
$reference = $data['reference'] ?? null;

// Initialize data array for Google Sheet logging with default 'failed' values
$sheetData = [
    'order_id' => $order_id,
    'payment_status' => $payment_status,
    'reference' => $reference,
    'timestamp' => date("Y-m-d H:i:s"),
    'sms_status' => 'failed',
    'email_status' => 'failed',
    'admin_email_status' => 'failed',
];


// Process the webhook only if it's a completed payment and has a valid order_id
if ($order_id && $payment_status === 'COMPLETED') {
    log_message("Processing COMPLETED payment for order_id: $order_id");
    
    $order_file = $tempFileDir . $order_id . '.json';
    
    if (file_exists($order_file)) {
        $orderDataJson = file_get_contents($order_file);
        $orderData = json_decode($orderDataJson, true);

        // Populate sheet data from the stored order file for logging
        $sheetData['buyer_phone'] = $orderData['billing']['phone'] ?? '';
        $sheetData['buyer_name'] = $orderData['billing']['name'] ?? '';
        $sheetData['amount'] = $orderData['billing']['amount'] ?? '';
        $sheetData['student_discount'] = $orderData['billing']['student_discount'] ?? 'not applied';
        $sheetData['buyer_email'] = $orderData['billing']['email'] ?? '';

        // --- Core Actions on Successful Payment ---
        
        // 1. Generate and Save the PDF file
        // CRITICAL CHANGE: We now pass the user's details to the PDF generator so it can create the QR code.
        $pdfPath = generateAndSavePdf(
            $orderData['cv_html'], 
            $orderData['user_details']['personalInfo'], 
            $order_id
        );
        
        if ($pdfPath) {
            log_message("PDF generated successfully: $pdfPath");

            // 2. Send the main email to the user with the CV attached
            $email_sent = sendCvEmail($orderData['billing']['email'], $orderData['billing']['name'], $pdfPath);
            $sheetData['email_status'] = $email_sent ? 'sent' : 'failed';
            log_message("User email sent status to {$orderData['billing']['email']}: " . ($email_sent ? 'Success' : 'Failure'));
            
            // 3. Send a notification email to the admin
            $admin_email_sent = sendAdminNotificationEmail($orderData, $order_id, $reference);
            $sheetData['admin_email_status'] = $admin_email_sent ? 'sent' : 'failed';
            log_message("Admin email sent status: " . ($admin_email_sent ? 'Success' : 'Failure'));

            // 4. Send an SMS confirmation to the user
            $sms_sent = sendConfirmationSms($orderData['billing']['phone'], $orderData['billing']['name']);
            $sheetData['sms_status'] = $sms_sent ? 'sent' : 'failed';
            log_message("SMS sent status to {$orderData['billing']['phone']}: " . ($sms_sent ? 'Success' : 'Failure'));

        } else {
            log_message("FATAL ERROR: PDF generation failed for order_id: $order_id. Check DomPDF configuration and file permissions for cv_exports/.");
        }
        
        // Keep the temporary order file so the user can download it from the success page.
        // It's important to have a cleanup process (e.g., a cron job) for old files in php/temp_orders/.
        log_message("Kept temp file for direct download link: $order_file");
        
    } else {
        log_message("ERROR: Order file not found for completed payment: $order_id. It may have been processed already in a previous webhook call.");
    }
} else {
    log_message("Webhook call ignored. Reason: Status was not 'COMPLETED' or order_id was missing. (Status: '{$payment_status}', Order ID: '{$order_id}')");
}

// Final action: update the Google Sheet with the results of our processing.
update_google_sheet($sheetData);
log_message("Google Sheet logging completed.");


// Respond to ZenoPay's server with a 200 OK to acknowledge that we received the webhook.
http_response_code(200);
echo json_encode(['status' => 'success', 'message' => 'Webhook received and processed.']);
?>