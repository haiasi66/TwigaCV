<?php
function sendConfirmationSms($phone, $name) {
    // Add logging from the sms.php script as well.
    require_once __DIR__ . '/webhook.php'; // Reuse the log_message function

    $apiKey = 'BeemAPI';
    $secretKey = 'BeemSecret';
    $beemUrl = 'BeemURL';

    // Normalize phone number to 255... format
    if (strpos($phone, '0') === 0) {
        $dest_addr = '255' . substr($phone, 1);
    } else {
        $dest_addr = $phone;
    }

    $message = "Habari {$name}, asante kwa kutumia TwigaCV. Wasifu wako (CV) umetumea kwenye barua prpe yako.";
    
    $postData = [
        'source_addr' => 'SenderID', // <-- This sender ID must be approved by Beem!
        'encoding' => 0,
        'schedule_time' => '',
        'message' => $message,
        'recipients' => [
            [
                'recipient_id' => '1',
                'dest_addr' => $dest_addr
            ]
        ]
    ];

    $ch = curl_init($beemUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization:Basic ' . base64_encode("$apiKey:$secretKey"),
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        log_message("SMS cURL Error: " . $error); // Detailed logging
        return false;
    }

    // Log the actual response from BEEM Africa for debugging
    log_message("BEEM SMS API Response: " . $response);

    $responseData = json_decode($response, true);
    
    if (isset($responseData['successful']) && $responseData['successful'] === true) {
        return true;
    } else {
        return false;
    }
}