<?php
// --- php/download.php (Final Version with Layout and QR Code Fixes) ---

// Make sure dompdf is loaded from the correct path
require_once __DIR__ . '/../dompdf/autoload.inc.php';

use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Creates the vCard data string from user info.
 * This is the PHP version of the JavaScript function.
 * @param array $personalInfo The user's personal info.
 * @return string The formatted vCard string.
 */
function formatVCardPHP($personalInfo) {
    $vCard = [
        'BEGIN:VCARD',
        'VERSION:3.0',
        'N:' . implode(';', [$personalInfo['lastName'], $personalInfo['firstName'], $personalInfo['middleName'], '', '']),
        'FN:' . implode(' ', [$personalInfo['firstName'], $personalInfo['middleName'], $personalInfo['lastName']]),
        'EMAIL:' . $personalInfo['email'],
        ...array_map(function($phone) { return 'TEL;TYPE=CELL:' . $phone; }, $personalInfo['phoneNumbers']),
        'ADR:;;' . $personalInfo['region'] . ';;;',
        'URL:https://www.twigacv.co.tz',
        'END:VCARD'
    ];
    return implode("\n", $vCard);
}

/**
 * Generates the PDF, now including the server-side generated QR code and layout fixes.
 * @param string $htmlContent The raw HTML of the CV.
 * @param array $personalInfo The user's personal details needed for the QR code.
 * @param string $orderId The unique order ID.
 * @return string|false The path to the saved PDF, or false on failure.
 */
function generateAndSavePdf($htmlContent, $personalInfo, $orderId) {
    try {
        // --- FIX #1: OVERLAY ISSUE ---
        // Add a max-height and overflow:hidden to the main container of the top section.
        // This will prevent the white overlay from bleeding down over other sections.
        $htmlContent = str_replace(
            '<section class="personal-info"',
            '<section class="personal-info" style="max-height: 265px; overflow: hidden;"',
            $htmlContent
        );

        // --- FIX #2 & #3: QR CODE POSITION AND LOGO CENTERING ---
        $vCardData = formatVCardPHP($personalInfo);
        $encodedVCard = urlencode($vCardData);
        $qrApiUrl = "https://api.qrserver.com/v1/create-qr-code/?size=128x128&data={$encodedVCard}&format=png";
        
        $qrCodeImageData = @file_get_contents($qrApiUrl);

        $qrCodeHtml = ''; // Default to empty string
        if ($qrCodeImageData) {
            $base64QrCode = 'data:image/png;base64,' . base64_encode($qrCodeImageData);
            $logoUrl = '';
            
            // The final HTML for the QR code cell, with all fixes applied.
            $qrCodeHtml = '
                <div class="qr-code-cell" style="position: relative; height: 160px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align:center;">
                    <!-- Added margin-top:30px to push the QR code down -->
                    <img src="' . $base64QrCode . '" width="128" height="128" alt="QR Code" style="margin-top: 10px;">
                    
                    <!-- Changed transform to -50%, -50% for perfect centering -->
                    <img src="' . $logoUrl . '" style="position: absolute; top: 50%; left: 50%; width: 30px; height: 30px; transform: translate(-50%, -50%);">
                    
                    <div class="qr-code-label" style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%); background-color: #2c3e50; color: #ffffff; padding: 5px 15px; border-radius: 15px; font-size: 10px; white-space: nowrap; z-index: 3;">
                        Connect with ' . htmlspecialchars($personalInfo['lastName']) . '
                    </div>
                </div>';
        }

        // Replace the placeholder QR code div with our server-generated version.
        $htmlContent = preg_replace(
            '/<td class="personal-info-right".*?>.*?<div class="qr-code-cell".*?>.*?<\/div>.*?<\/td>/s',
            '<td class="personal-info-right" style="width: 30%; text-align: center; background-color: #f8f9fa; border: 1px solid #eaeaea; padding:25px; vertical-align: top;">' . $qrCodeHtml . '</td>',
            $htmlContent
        );


        $options = new Options();
        $options->set('isRemoteEnabled', true); // Allows DomPDF to fetch the logo and QR code
        $options->set('tempDir', __DIR__ . '/temp_orders');

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($htmlContent);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $outputDir = __DIR__ . '/cv_exports/';
        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0775, true);
        }
        $filePath = $outputDir . 'TwigaCV-' . $orderId . '.pdf';
        
        file_put_contents($filePath, $dompdf->output());
        
        return $filePath;
    } catch (Exception $e) {
        error_log("Dompdf error for Order ID {$orderId}: " . $e->getMessage());
        return false;
    }
}