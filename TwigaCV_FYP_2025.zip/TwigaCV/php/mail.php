<?php

/**
 * Sends the user's CV via email using the native PHP mail() function.
 * This function constructs a multipart MIME message to include both HTML content and a PDF attachment.
 *
 * @param string $toEmail The recipient's email address.
 * @param string $toName The recipient's name.
 * @param string $attachmentPath The server file path to the PDF to attach.
 * @return bool True on success, false on failure.
 */
function sendCvEmail($toEmail, $toName, $attachmentPath) {
    if (!file_exists($attachmentPath)) {
        error_log("Attachment file not found: " . $attachmentPath);
        return false;
    }

    $subject = 'Your Professional CV from TwigaCV is Here!';
    $from = '';

    // Load HTML email body from the template file
    $htmlContent = file_get_contents(__DIR__ . '/email_template.html');
    $htmlContent = str_replace('{USER_NAME}', htmlspecialchars($toName), $htmlContent);

    // Read attachment content
    $attachmentContent = file_get_contents($attachmentPath);
    $attachmentEncoded = chunk_split(base64_encode($attachmentContent));
    $attachmentName = basename($attachmentPath);

    // Create a unique boundary string
    $boundary = "PHP-mixed-" . md5(time());
    $eol = "\r\n";

    // --- CONSTRUCT HEADERS ---
    $headers = "From: " . $from . $eol;
    $headers .= "MIME-Version: 1.0" . $eol;
    // Specify the main content type as multipart/mixed
    $headers .= "Content-Type: multipart/mixed; boundary=\"" . $boundary . "\"" . $eol;

    // --- CONSTRUCT MESSAGE BODY ---
    $messageBody = "--" . $boundary . $eol;

    // Part 1: HTML message
    $messageBody .= "Content-Type: text/html; charset=\"UTF-8\"" . $eol;
    $messageBody .= "Content-Transfer-Encoding: 7bit" . $eol . $eol;
    $messageBody .= $htmlContent . $eol . $eol;

    // Part 2: Attachment
    $messageBody .= "--" . $boundary . $eol;
    $messageBody .= "Content-Type: application/pdf; name=\"" . $attachmentName . "\"" . $eol;
    $messageBody .= "Content-Transfer-Encoding: base64" . $eol;
    $messageBody .= "Content-Disposition: attachment" . $eol . $eol;
    $messageBody .= $attachmentEncoded . $eol;

    // End of message
    $messageBody .= "--" . $boundary . "--";

    // Send the email
    if (mail($toEmail, $subject, $messageBody, $headers)) {
        return true;
    } else {
        error_log("Native mail() function failed to send user email to: " . $toEmail);
        return false;
    }
}


/**
 * Sends a notification email to the admin using the native PHP mail() function.
 *
 * @param array $orderData The associative array containing all order details.
 * @param string $orderId The unique order ID.
 * @param string $reference The ZenoPay transaction reference.
 * @return bool True on success, false on failure.
 */
function sendAdminNotificationEmail($orderData, $orderId, $reference) {
    $to = '';
    $subject = 'New CV Sale Notification - Order: ' . $orderId;
    $from = '';

    // Load HTML email body from the template file and replace placeholders
    $body = file_get_contents(__DIR__ . '/admin_email_template.html');
    $body = str_replace('{ORDER_ID}', htmlspecialchars($orderId), $body);
    $body = str_replace('{REFERENCE}', htmlspecialchars($reference), $body);
    $body = str_replace('{BUYER_NAME}', htmlspecialchars($orderData['billing']['name']), $body);
    $body = str_replace('{BUYER_EMAIL}', htmlspecialchars($orderData['billing']['email']), $body);
    $body = str_replace('{BUYER_PHONE}', htmlspecialchars($orderData['billing']['phone']), $body);
    $body = str_replace('{AMOUNT}', htmlspecialchars($orderData['billing']['amount']), $body);
    $body = str_replace('{DISCOUNT}', htmlspecialchars($orderData['billing']['student_discount']), $body);
    $body = str_replace('{TIMESTAMP}', date("Y-m-d H:i:s"), $body);

    // Headers for sending HTML email
    $headers = "From: " . $from . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    // Send the email
    if (mail($to, $subject, $body, $headers)) {
        return true;
    } else {
        error_log("Native mail() function failed to send admin notification email.");
        return false;
    }
}