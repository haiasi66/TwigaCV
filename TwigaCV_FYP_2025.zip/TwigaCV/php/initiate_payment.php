<?php
session_start();
header('Content-Type: application/json');

// --- Configuration ---
$zenoPayApiKey = 'API Key';
$zenoPayApiUrl = 'ZenoAPI';
$webhookUrl = 'Webhook URL'; // IMPORTANT: This must be a live, public URL
$tempFileDir = __DIR__ . '/temp_orders/';

// --- Helper Function ---
function generate_uuid() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

// --- Main Logic ---
$response = ['success' => false, 'message' => 'An error occurred.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['form_data'])) {
    
    // Create temp directory if it doesn't exist
    if (!is_dir($tempFileDir)) {
        mkdir($tempFileDir, 0755, true);
    }

    $buyer_name = trim($_POST['fullName']);
    $buyer_email = trim($_POST['email']);
    $buyer_phone = trim($_POST['phone']);
    $amount = filter_var($_POST['amount'], FILTER_VALIDATE_INT);
    $discount_code = trim($_POST['discount_code'] ?? '');
    
    if (empty($buyer_name) || empty($buyer_email) || empty($buyer_phone) || !$amount) {
        $response['message'] = 'Invalid billing details provided.';
        echo json_encode($response);
        exit;
    }

    $order_id = generate_uuid();
    
    // Store all necessary data in a temporary file named after the order_id
    $order_data = [
        'user_details' => $_SESSION['form_data'],
        'cv_html' => $_SESSION['cv_content_html'],
        'billing' => [
            'name' => $buyer_name,
            'email' => $buyer_email,
            'phone' => $buyer_phone,
            'amount' => $amount,
            'student_discount' => !empty($discount_code) ? 'applied' : 'not applied'
        ]
    ];

    file_put_contents($tempFileDir . $order_id . '.json', json_encode($order_data));

    // Prepare payload for ZenoPay
    $payload = json_encode([
        'order_id' => $order_id,
        'buyer_email' => $buyer_email,
        'buyer_name' => $buyer_name,
        'buyer_phone' => $buyer_phone,
        'amount' => $amount,
        'webhook_url' => $webhookUrl
    ]);

    // Make cURL request to ZenoPay
    $ch = curl_init($zenoPayApiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'x-api-key: ' . $zenoPayApiKey
    ]);

    $zeno_response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $zeno_data = json_decode($zeno_response, true);

    if ($http_code == 200 && isset($zeno_data['status']) && $zeno_data['status'] === 'success') {
        $response['success'] = true;
        $response['message'] = 'Payment initiated successfully.';
        $response['order_id'] = $order_id;
    } else {
        $response['message'] = $zeno_data['message'] ?? 'Failed to communicate with payment provider.';
        // Clean up temp file on failure
        if(file_exists($tempFileDir . $order_id . '.json')){
            unlink($tempFileDir . $order_id . '.json');
        }
    }
} else {
    $response['message'] = 'Invalid session or request method.';
}

echo json_encode($response);