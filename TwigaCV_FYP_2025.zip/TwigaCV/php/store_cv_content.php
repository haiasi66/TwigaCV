<?php
session_start();
header('Content-Type: application/json');

// reCAPTCHA Secret Key
$secretKey = '';

$response = ['success' => false, 'message' => 'An unknown error occurred.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // 1. Validate reCAPTCHA
    if (!isset($data['recaptcha']) || empty($data['recaptcha'])) {
        $response['message'] = 'reCAPTCHA verification failed. Please try again.';
        echo json_encode($response);
        exit;
    }

    $recaptcha_url = '';
    $recaptcha_data = [
        'secret'   => $secretKey,
        'response' => $data['recaptcha'],
        'remoteip' => $_SERVER['REMOTE_ADDR'],
    ];

    $options = ['http' => [
        'method' => 'POST',
        'content' => http_build_query($recaptcha_data)
    ]];

    $context  = stream_context_create($options);
    $verify = file_get_contents($recaptcha_url, false, $context);
    $captcha_success = json_decode($verify);

    if ($captcha_success->success == false) {
        $response['message'] = 'reCAPTCHA verification failed. Are you a robot?';
    } else if (!isset($data['formData']) || !isset($data['cvContent'])) {
        $response['message'] = 'Incomplete data received.';
    } else {
        // 2. Store data in session
        $_SESSION['form_data'] = $data['formData'];
        $_SESSION['cv_content_html'] = $data['cvContent'];

        // 3. Prepare successful response
        $response['success'] = true;
        $response['message'] = 'Data stored successfully.';
        $response['redirectUrl'] = 'billing.html';
    }
} else {
    $response['message'] = 'Invalid request method.';
}

echo json_encode($response);