<?php
header('Content-Type: application/json');

// --- Configuration ---
$zenoPayApiKey = '';
$zenoPayStatusUrl = '';
$tempFileDir = __DIR__ . '/temp_orders/';

$order_id = $_GET['order_id'] ?? null;

if (empty($order_id)) {
    echo json_encode(['status' => 'error', 'message' => 'Order ID is missing.']);
    exit;
}

// Before hitting the API, check if the order has already been processed and cleaned up.
// If the temp file is gone, it means the webhook likely processed it successfully.
if (!file_exists($tempFileDir . $order_id . '.json')) {
    echo json_encode(['payment_status' => 'COMPLETED', 'message' => 'Status confirmed.']);
    exit;
}

// If temp file exists, poll the API
$url_with_params = $zenoPayStatusUrl . '?order_id=' . urlencode($order_id);

$ch = curl_init($url_with_params);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'x-api-key: ' . $zenoPayApiKey
]);

$zeno_response = curl_exec($ch);
curl_close($ch);

$zeno_data = json_decode($zeno_response, true);

if (isset($zeno_data['data'][0]['payment_status'])) {
    $payment_status = $zeno_data['data'][0]['payment_status'];
    
    // If completed via poll, trigger the webhook logic here as a fallback
    if ($payment_status === 'COMPLETED') {
        // You can include the logic from webhook.php here, or simply let the polling client redirect
        // and trust the main webhook will handle processing. The latter is simpler.
    }
    
    echo json_encode(['payment_status' => $payment_status]);
} else {
    echo json_encode(['payment_status' => 'PENDING', 'message' => 'Status check inconclusive.']);
}