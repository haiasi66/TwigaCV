document.addEventListener('DOMContentLoaded', function() {
    // --- ELEMENT REFERENCES ---
    const cvForm = document.getElementById('cvForm');
    const modal = document.getElementById('cvModal');
    const cvPreview = document.getElementById('cvPreview');
    const keepEditingBtn = document.getElementById('keepEditingBtn');
    const downloadCvBtn = document.getElementById('downloadCvBtn');
    
    const addElimuBtn = document.getElementById('addElimuBtn');
    const elimuFields = document.getElementById('elimuFields');
    const addHistoriaKaziBtn = document.getElementById('addHistoriaKaziBtn');
    const historiaKaziFields = document.getElementById('historiaKaziFields');
    const addUjuziBtn = document.getElementById('addUjuziBtn');
    const ujuziFields = document.getElementById('ujuziFields');
    const addNinapendaBtn = document.getElementById('addNinapendaBtn');
    const ninapendaFields = document.getElementById('ninapendaFields');
    const addWadhaminiBtn = document.getElementById('addWadhaminiBtn');
    const wadhaminiFields = document.getElementById('wadhaminiFields');

    // --- DATA & HELPER FUNCTIONS ---
    const tanzaniaRegions = ["Arusha", "Dar es Salaam", "Dodoma", "Geita", "Iringa", "Kagera", "Katavi", "Kigoma", "Kilimanjaro", "Lindi", "Manyara", "Mara", "Mbeya", "Morogoro", "Mtwara", "Mwanza", "Njombe", "Pwani", "Rukwa", "Ruvuma", "Shinyanga", "Simiyu", "Singida", "Songwe", "Tabora", "Tanga", "Zanzibar Mjini Magharibi", "Zanzibar Kaskazini", "Zanzibar Kusini"];

    function createRegionDropdown() {
        const select = document.createElement('select');
        select.required = true;
        select.innerHTML = `<option value="" disabled selected>Chagua Mkoa</option>` + tanzaniaRegions.map(region => `<option value="${region}">${region}</option>`).join('');
        return select;
    }

    const mainMkoaSelect = document.getElementById('mkoa');
    mainMkoaSelect.innerHTML = createRegionDropdown().innerHTML;
    mainMkoaSelect.querySelector('option[value=""]').textContent = "Anwani na Mkoa";
    
    // --- DYNAMIC FIELD FUNCTIONS ---
    function addDynamicField(container, className, placeholder, maxItems, innerHTMLFactory) {
        if (container.children.length >= maxItems) {
            alert(`Unaweza kuongeza hadi ${maxItems} pekee.`);
            return;
        }
        const group = document.createElement('div');
        group.className = className;
        group.innerHTML = innerHTMLFactory();
        group.querySelector('.remove-btn').addEventListener('click', () => group.remove());
        container.appendChild(group);
    }
    
    addElimuBtn.addEventListener('click', () => addDynamicField(elimuFields, 'elimu-group', '', 9, () => `
        <input type="text" class="chuo" placeholder="Taasisi ya Elimu" required>
        <input type="text" class="cheti" placeholder="Cheti Ulichopata" required>
        <div class="inline-group"><p>Kuanzia:</p><p>Kumaliza:</p></div>
        <div class="inline-group"><input type="month" class="elimuStart" required><input type="month" class="elimuEnd" required></div>
        <button type="button" class="remove-btn">Ondoa Elimu</button>`
    ));

    addHistoriaKaziBtn.addEventListener('click', () => {
        if (historiaKaziFields.children.length >= 9) return alert(`Unaweza kuongeza hadi 9 pekee.`);
        const group = document.createElement('div');
        group.className = 'kazi-group';
        group.innerHTML = `
            <input type="text" class="mwajiri" placeholder="Mwajiri" required>
            <input type="text" class="kazi" placeholder="Cheo" required>
            <div class="inline-group"><p>Kuanzia:</p><p>Kumaliza:</p></div>
            <div class="inline-group"><input type="month" class="kaziStart" required><input type="month" class="kaziEnd" required></div>
            <button type="button" class="remove-btn">Ondoa Kazi</button>`;
        const regionSelect = createRegionDropdown();
        regionSelect.className = 'mkoa';
        group.insertBefore(regionSelect, group.children[2]);
        group.querySelector('.remove-btn').addEventListener('click', () => group.remove());
        historiaKaziFields.appendChild(group);
    });

    addUjuziBtn.addEventListener('click', () => addDynamicField(ujuziFields, 'ujuzi-group', 'Ujuzi', 20, () => `<input type="text" class="ujuzi" placeholder="Ujuzi" required><button type="button" class="remove-btn">Ondoa Ujuzi</button>`));
    addNinapendaBtn.addEventListener('click', () => addDynamicField(ninapendaFields, 'ninapenda-group', 'Unachopenda', 20, () => `<input type="text" class="ninapenda" placeholder="Unachopenda" required><button type="button" class="remove-btn">Ondoa</button>`));
    
    addWadhaminiBtn.addEventListener('click', () => {
        if (wadhaminiFields.children.length >= 3) return alert(`Unaweza kuongeza wadhamini 3 pekee.`);
        const group = document.createElement('div');
        group.className = 'wadhamini-group';
        group.innerHTML = `
            <input type="text" class="jinaMdhamini" placeholder="Jina Kamili" required>
            <input type="text" class="kaziMdhamini" placeholder="Kazi" required>
            <div class="inline-group"><input type="tel" class="simuMdhamini" placeholder="Simu (074...)" required><input type="email" class="baruaPepeMdhamini" placeholder="Barua Pepe" required></div>
            <button type="button" class="remove-btn">Ondoa Mdhamini</button>`;
        const regionSelect = createRegionDropdown();
        regionSelect.className = 'mkoaMdhamini';
        group.insertBefore(regionSelect, group.children[2]);
        group.querySelector('.remove-btn').addEventListener('click', () => group.remove());
        wadhaminiFields.appendChild(group);
    });

    // --- VALIDATION FUNCTIONS ---
    const validateEmail = email => /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(String(email).toLowerCase());
    const validatePhone = phone => /^(07|06)\d{8}$/.test(phone);

    function validateForm() {
        for (const el of document.querySelectorAll('[required]')) { if (!el.value) { el.focus(); alert(`Tafadhali jaza sehemu ya: ${el.placeholder || el.labels[0].textContent}`); return false; } }
        for (const phone of document.querySelectorAll('input[type="tel"]')) { if (!validatePhone(phone.value)) { phone.focus(); alert(`Namba ya simu '${phone.value}' si sahihi. Anza na 07 au 06. Na ni tarakimu kumi(10)`); return false; } }
        for (const email of document.querySelectorAll('input[type="email"]')) { if (!validateEmail(email.value)) { email.focus(); alert(`Anwani ya barua pepe '${email.value}' si sahihi.`); return false; } }
        let datesValid = true;
        document.querySelectorAll('.elimu-group, .kazi-group').forEach(g => {
            const start = g.querySelector('[class*="Start"]').value; const end = g.querySelector('[class*="End"]').value;
            if (start && end && start > end) { alert('Tarehe ya kuanza haiwezi kuwa baada ya tarehe ya kumaliza.'); datesValid = false; }
        });
        if (!datesValid) return false;
        if (grecaptcha.getResponse() === "") { alert("Tafadhali thibitisha wewe si roboti."); return false; }
        return true;
    }

    // --- MAIN EVENT LISTENER ---
    cvForm.addEventListener('submit', function(event) {
        event.preventDefault();
        if (!validateForm()) return;

        // --- Data Collection ---
        const formData = {
            taarifaBinafsi: { jinaKwanza: document.getElementById('jinaKwanza').value, jinaKati: document.getElementById('jinaKati').value, jinaMwisho: document.getElementById('jinaMwisho').value, kuzaliwa: document.getElementById('kuzaliwa').value, simu: document.querySelector('.simu').value, baruaPepe: document.getElementById('baruaPepe').value, mkoa: document.getElementById('mkoa').value, },
            historiaElimu: Array.from(document.querySelectorAll('.elimu-group')).map(e => ({ chuo: e.querySelector('.chuo').value, cheti: e.querySelector('.cheti').value, elimuStart: e.querySelector('.elimuStart').value, elimuEnd: e.querySelector('.elimuEnd').value })),
            historiaKazi: Array.from(document.querySelectorAll('.kazi-group')).map(k => ({ mwajiri: k.querySelector('.mwajiri').value, kazi: k.querySelector('.kazi').value, mkoa: k.querySelector('.mkoa').value, kaziStart: k.querySelector('.kaziStart').value, kaziEnd: k.querySelector('.kaziEnd').value })),
            ujuzi: Array.from(document.querySelectorAll('.ujuzi-group')).map(u => u.querySelector('.ujuzi').value).filter(Boolean),
            ninapenda: Array.from(document.querySelectorAll('.ninapenda-group')).map(n => n.querySelector('.ninapenda').value).filter(Boolean),
            wadhamini: Array.from(document.querySelectorAll('.wadhamini-group')).map(w => ({ jinaMdhamini: w.querySelector('.jinaMdhamini').value, kaziMdhamini: w.querySelector('.kaziMdhamini').value, mkoaMdhamini: w.querySelector('.mkoaMdhamini').value, simuMdhamini: w.querySelector('.simuMdhamini').value, baruaPepeMdhamini: w.querySelector('.baruaPepeMdhamini').value })),
            uthibitisho: document.getElementById('declarationName').value,
        };

        // --- Build & Display Enhanced Preview ---
        const h = s => s.replace(/</g, "&lt;").replace(/>/g, "&gt;"); // Basic sanitize for preview
        let previewHtml = `<div class="preview-container"><div class="preview-header"><h1>${h(formData.taarifaBinafsi.jinaKwanza)} ${h(formData.taarifaBinafsi.jinaMwisho)}</h1><div class="divider"></div></div>`;
        previewHtml += `<div class="preview-section"><div class="preview-personal-info">
            <p><strong>Tarehe ya Kuzaliwa:</strong> ${h(formData.taarifaBinafsi.kuzaliwa)}</p><p><strong>Simu:</strong> ${h(formData.taarifaBinafsi.simu)}</p>
            <p><strong>Barua Pepe:</strong> ${h(formData.taarifaBinafsi.baruaPepe)}</p><p><strong>Mkoa:</strong> ${h(formData.taarifaBinafsi.mkoa)}</p></div></div>`;
        if (formData.historiaElimu.length > 0) {
            previewHtml += `<div class="preview-section"><h2>Historia ya Elimu</h2><table><thead><tr><th>Taasisi</th><th>Cheti</th><th>Kuanzia</th><th>Kumaliza</th></tr></thead><tbody>`;
            formData.historiaElimu.forEach(e => { previewHtml += `<tr><td>${h(e.chuo)}</td><td>${h(e.cheti)}</td><td>${h(e.elimuStart)}</td><td>${h(e.elimuEnd)}</td></tr>`; });
            previewHtml += `</tbody></table></div>`;
        }
        if (formData.historiaKazi.length > 0) {
            previewHtml += `<div class="preview-section"><h2>Uzoefu wa Kazi</h2><table><thead><tr><th>Mwajiri</th><th>Cheo</th><th>Mkoa</th><th>Kuanzia</th><th>Kumaliza</th></tr></thead><tbody>`;
            formData.historiaKazi.forEach(k => { previewHtml += `<tr><td>${h(k.mwajiri)}</td><td>${h(k.kazi)}</td><td>${h(k.mkoa)}</td><td>${h(k.kaziStart)}</td><td>${h(k.kaziEnd)}</td></tr>`; });
            previewHtml += `</tbody></table></div>`;
        }
        if (formData.ujuzi.length > 0) {
            previewHtml += `<div class="preview-section"><h2>Ujuzi</h2><div class="preview-grid">${formData.ujuzi.map(u => `<div class="preview-grid-item">${h(u)}</div>`).join('')}</div></div>`;
        }
        if (formData.ninapenda.length > 0) {
            previewHtml += `<div class="preview-section"><h2>Ninapenda</h2><div class="preview-grid">${formData.ninapenda.map(n => `<div class="preview-grid-item">${h(n)}</div>`).join('')}</div></div>`;
        }
        if (formData.wadhamini.length > 0) {
            previewHtml += `<div class="preview-section"><h2>Wadhamini</h2><table><thead><tr><th>Jina</th><th>Kazi</th><th>Anwani/Mkoa</th><th>Simu</th><th>Barua Pepe</th></tr></thead><tbody>`;
            formData.wadhamini.forEach(w => { previewHtml += `<tr><td>${h(w.jinaMdhamini)}</td><td>${h(w.kaziMdhamini)}</td><td>${h(w.mkoaMdhamini)}</td><td>${h(w.simuMdhamini)}</td><td>${h(w.baruaPepeMdhamini)}</td></tr>`; });
            previewHtml += `</tbody></table></div>`;
        }
        previewHtml += `</div>`; // Close preview-container
        cvPreview.innerHTML = previewHtml;
        modal.style.display = 'block';

        // --- Attach Download Logic ---
        downloadCvBtn.onclick = async () => {
            downloadCvBtn.textContent = 'Inatayarisha...';
            downloadCvBtn.disabled = true;
            try {
                const response = await fetch('/swahili/pakua.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({...formData, 'g-recaptcha-response': grecaptcha.getResponse()}) });
                if (response.ok && response.headers.get('content-type')?.includes('application/pdf')) {
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a'); a.href = url; a.download = `TwigaCV_${formData.taarifaBinafsi.jinaKwanza}.pdf`;
                    document.body.appendChild(a); a.click(); a.remove(); window.URL.revokeObjectURL(url);
                    alert('Hongera! Wasifu umepakuliwa na kutumwa kwa barua pepe yako.');
                    window.location.href = 'asante.php';
                } else { const errorText = await response.text(); throw new Error(`Server ilijibu kosa: ${errorText}`); }
            } catch (error) { console.error('Download error:', error); alert(`Kuna tatizo la kuunganisha. Tafadhali jaribu tena.\nMaelezo: ${error.message}`);
            } finally { downloadCvBtn.textContent = 'Pakua Wasifu'; downloadCvBtn.disabled = false; grecaptcha.reset(); }
        };
    });
    
    // Modal controls
    keepEditingBtn.addEventListener('click', () => modal.style.display = 'none');
    window.addEventListener('click', (event) => { if (event.target === modal) modal.style.display = 'none'; });
});