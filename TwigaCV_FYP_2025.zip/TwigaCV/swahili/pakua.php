<?php
// ENABLE ERROR REPORTING FOR DEBUGGING - REMOVE THESE LINES FOR PRODUCTION
ini_set('display_errors', 1);
error_reporting(E_ALL);

// ===============================================
// CORRECTED FILE PATHS
// ===============================================
// Path to Dompdf: Go up one level from /swahili, then into /php
require_once __DIR__ . '/../dompdf/autoload.inc.php';

// Path to mail.php: It is in the same directory (/swahili)
require_once __DIR__ . '/mail.php';

use Dompdf\Dompdf;
use Dompdf\Options;

session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die("Method Not Allowed.");
}

$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    die('Invalid JSON data received.');
}

// reCAPTCHA Validation
$recaptcha_response = $input['g-recaptcha-response'] ?? '';
$secret_key = '6LdvpXErAAAAAKcOXaTmsfZQ6ZFmCEmUSsifYyol';

if (!function_exists('curl_init')) {
    http_response_code(500);
    die("Server Error: cURL PHP extension is not installed or enabled.");
}
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['secret' => $secret_key, 'response' => $recaptcha_response]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$recaptcha_result = json_decode(curl_exec($ch), true);
curl_close($ch);

if (!($recaptcha_result['success'] ?? false)) {
    http_response_code(403);
    die("reCAPTCHA verification failed. Please try again.");
}

// Function to build CV HTML on the server (More secure)
// In swahili/pakua.php

function buildCvHtml($data) {
    $h = function($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); };
    $fullName = $h(strtoupper(trim($data['taarifaBinafsi']['jinaKwanza'] . ' ' . $data['taarifaBinafsi']['jinaKati'] . ' ' . $data['taarifaBinafsi']['jinaMwisho'])));
    
    // Elimu section (No changes needed)
    $elimuHtml = '';
    if (!empty($data['historiaElimu'])) {
        $rows = '';
        foreach ($data['historiaElimu'] as $e) {
            $rows .= '<tr><td class="institution-column">' . $h($e['chuo']) . '</td><td>' . $h($e['cheti']) . '</td><td class="date-column">' . $h($e['elimuStart']) . '</td><td class="date-column">' . $h($e['elimuEnd']) . '</td></tr>';
        }
        $elimuHtml = '<section class="section"><h2 class="section-title">Historia ya Elimu</h2><table class="professional-table"><thead><tr><th>Taasisi ya Elimu</th><th>Cheti</th><th>Kuanzia</th><th>Kumaliza</th></tr></thead><tbody>' . $rows . '</tbody></table></section>';
    }

    // Work Experience section (No changes needed)
    $kaziHtml = '';
    if (!empty($data['historiaKazi'])) {
        $rows = '';
        foreach ($data['historiaKazi'] as $k) {
            $rows .= '<tr><td class="institution-column">' . $h($k['mwajiri']) . '</td><td>' . $h($k['kazi']) . '</td><td>' . $h($k['mkoa']) . '</td><td class="date-column">' . $h($k['kaziStart']) . '</td><td class="date-column">' . $h($k['kaziEnd']) . '</td></tr>';
        }
        $kaziHtml = '<section class="section"><h2 class="section-title">Uzoefu wa Kazi</h2><table class="professional-table"><thead><tr><th>Mwajiri</th><th>Cheo</th><th>Mkoa</th><th>Kuanzia</th><th>Kumaliza</th></tr></thead><tbody>' . $rows . '</tbody></table></section>';
    }

    // ==================
    // NEW CODE STARTS HERE
    // ==================
    
    // Function to generate grids for Skills and Hobbies
    $makeGrid = function($items, $title) use ($h) {
        if (empty($items)) return '';
        $html = '<section class="section"><h2 class="section-title">' . $title . '</h2><table class="skills-table">';
        $chunks = array_chunk($items, 4); // Creates rows of 4
        foreach ($chunks as $row) {
            $html .= '<tr>';
            foreach ($row as $item) {
                $html .= '<td>' . $h($item) . '</td>';
            }
            if (count($row) < 4) { // Fill empty cells if the row is not full
                $html .= str_repeat('<td></td>', 4 - count($row));
            }
            $html .= '</tr>';
        }
        $html .= '</table></section>';
        return $html;
    };

    // Create HTML for "Ujuzi" and "Ninapenda"
    $ujuziHtml = $makeGrid($data['ujuzi'] ?? [], 'Ujuzi');
    $ninapendaHtml = $makeGrid($data['ninapenda'] ?? [], 'Ninapenda');
    
    // ==================
    // NEW CODE ENDS HERE
    // ==================

    // Referees section (No changes needed)
    $wadhaminiHtml = '';
    if (!empty($data['wadhamini'])) {
        $rows = '';
        foreach($data['wadhamini'] as $w) {
            $rows .= '<tr><td class="institution-column">' . $h($w['jinaMdhamini']) . '</td><td>' . $h($w['kaziMdhamini']) . '</td><td>' . $h($w['mkoaMdhamini']) . '</td><td>' . $h($w['simuMdhamini']) . '</td><td>' . $h($w['baruaPepeMdhamini']) . '</td></tr>';
        }
        $wadhaminiHtml = '<section class="section"><h2 class="section-title">Wadhamini</h2><table class="professional-table"><thead><tr><th>Jina Kamili</th><th>Kazi</th><th>Anwani/Mkoa</th><th>Simu</th><th>Barua Pepe</th></tr></thead><tbody>' . $rows . '</tbody></table></section>';
    }

    // Return the complete HTML structure
    return <<<HTML
    <!DOCTYPE html>
    <html lang="sw">
    <head><meta charset="UTF-8"><title>Wasifu</title>
    <style>
        @page { margin: 20px 25px; }
        body { font-family: 'DejaVu Sans', Arial, sans-serif; line-height: 1.5; color: #333; font-size: 10pt; }
        .cv-container { width: 100%; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 25px; }
        .header h1 { font-size: 18pt; text-transform: uppercase; margin-bottom: 5px; color: #1e3a8a; }
        .header-line { border-bottom: 2px solid #3b82f6; width: 70%; margin: 0 auto; }
        .personal-info { margin-bottom: 20px; padding: 10px; background-color: #f3f4f6; border-radius: 5px; border-left: 4px solid #3b82f6; page-break-inside: avoid; }
        .personal-info-table { width: 100%; border-collapse: collapse; }
        .personal-info-table td { padding: 5px; vertical-align: top; width: 50%;}
        .info-label { font-weight: bold; }
        .section { margin-bottom: 15px; page-break-inside: avoid; }
        .section-title { font-size: 12pt; font-weight: bold; color: #1e3a8a; margin-bottom: 8px; padding-bottom: 3px; border-bottom: 1.5px solid #9ca3af; text-transform: uppercase; }
        .professional-table { width: 100%; border-collapse: collapse; font-size: 9pt; }
        .professional-table th, .professional-table td { border: 1px solid #d1d5db; padding: 6px; text-align: left; }
        .professional-table th { background-color: #e5e7eb; font-weight: bold; }
        .institution-column { font-weight: bold; color: #1d4ed8; }
        .date-column { white-space: nowrap; }
        .skills-table { width: 100%; border-collapse: separate; border-spacing: 5px; page-break-inside: avoid; } /* Added this style */
        .skills-table td { background-color: #f3f4f6; border: 1px solid #e5e7eb; padding: 5px 8px; text-align: center; border-radius: 4px; width: 25%; } /* Added this style */
        .declaration { background-color: #f3f4f6; padding: 12px; border-radius: 5px; margin-top: 20px; page-break-inside: avoid; }
        .declaration p { font-style: italic; }
        .declaration-footer { text-align: center; font-size: 8pt; color: #6b7280; margin-top: 15px; }
    </style>
    </head><body>
    <div class="cv-container">
        <div class="header"><h1>{$fullName}</h1><div class="header-line"></div></div>
        <section class="personal-info">
            <table class="personal-info-table">
                <tr><td><span class="info-label">Tarehe ya Kuzaliwa:</span> {$h($data['taarifaBinafsi']['kuzaliwa'])}</td><td><span class="info-label">Simu:</span> {$h($data['taarifaBinafsi']['simu'])}</td></tr>
                <tr><td><span class="info-label">Barua Pepe:</span> {$h($data['taarifaBinafsi']['baruaPepe'])}</td><td><span class="info-label">Mkoa:</span> {$h($data['taarifaBinafsi']['mkoa'])}</td></tr>
            </table>
        </section>
        
        <!-- ======================= -->
        <!-- UPDATED ORDER OF SECTIONS -->
        <!-- ======================= -->
        {$elimuHtml}
        {$kaziHtml}
        {$ujuziHtml}
        {$ninapendaHtml}
        {$wadhaminiHtml}
        
        <section class="declaration"><p>Mimi, <strong>{$h($data['uthibitisho'])}</strong>, Ninakubali kwamba, kwa kadri ya ufahamu wangu, taarifa zilizomo hapa ni sahihi na kwa muhtasari zinaelezea mimi, sifa zangu, na uzoefu wangu.</p><div class="declaration-footer">Imetolewa na TwigaCV Tanzania • www.twigacv.co.tz</div></section>
    </div>
    </body></html>
HTML;
}

try {
    $cvHtml = buildCvHtml($input);
    
    $options = new Options();
    $options->set('isRemoteEnabled', true);
    $options->set('defaultFont', 'DejaVu Sans'); // 'DejaVu Sans' has better character support
    
    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($cvHtml);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    
    $pdf_output = $dompdf->output();
    $userEmail = $input['taarifaBinafsi']['baruaPepe'];
    $userFullName = trim($input['taarifaBinafsi']['jinaKwanza'] . ' ' . $input['taarifaBinafsi']['jinaMwisho']);

    sendCvEmail($userEmail, $userFullName, $pdf_output);
    
    $_SESSION['cv_generated_successfully'] = true;

    // Use a clean filename for the download
    $filename = "TwigaCV_" . preg_replace('/[^A-Za-z0-9_\-]/', '', $userFullName) . ".pdf";
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($pdf_output));
    
    echo $pdf_output;

} catch (Exception $e) {
    http_response_code(500);
    error_log("PDF Generation Error: " . $e->getMessage());
    die("A server error occurred: " . $e->getMessage()); // Show specific error for debugging
}
?>