<?php

function sendCvEmail($to, $fullName, $pdfData) {
    $templatePath = __DIR__ . '/email_template.html';
    if (!file_exists($templatePath)) {
        error_log("Email template not found at: " . $templatePath);
        return false;
    }
    
    $subject = "Wasifu wako kutoka TwigaCV Uko Tayari!";
    $from = "";

    // Load and customize email template
    $email_body = file_get_contents($templatePath);
    $email_body = str_replace('{{JINA_KAMILI}}', htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8'), $email_body);

    // Create a boundary for the multipart message
    $boundary = "PHP-mixed-" . md5(time());
    $eol = "\r\n";

    // --- Main headers ---
    $headers = "From: TwigaCV <" . $from . ">" . $eol;
    $headers .= "MIME-Version: 1.0" . $eol;
    $headers .= "Content-Type: multipart/mixed; boundary=\"" . $boundary . "\"" . $eol . $eol;
    
    // --- Message Body (HTML part) ---
    $body = "--" . $boundary . $eol;
    $body .= "Content-Type: text/html; charset=UTF-8" . $eol;
    $body .= "Content-Transfer-Encoding: 7bit" . $eol . $eol;
    $body .= $email_body . $eol;

    // --- Attachment (PDF part) ---
    $pdf_base64 = base64_encode($pdfData);
    $body .= "--" . $boundary . $eol;
    $body .= "Content-Type: application/pdf; name=\"Wasifu_TwigaCV.pdf\"" . $eol;
    $body .= "Content-Transfer-Encoding: base64" . $eol;
    $body .= "Content-Disposition: attachment; filename=\"Wasifu_TwigaCV.pdf\"" . $eol . $eol;
    $body .= chunk_split($pdf_base64) . $eol;
    $body .= "--" . $boundary . "--";

    // Send the email
    return mail($to, $subject, $body, $headers);
}

?>