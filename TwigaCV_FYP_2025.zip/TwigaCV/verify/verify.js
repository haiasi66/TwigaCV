let timer;
let timeoutId;

function getStudentImage() {
    const registration = document.getElementById('registration').value;
    const errorContainer = document.getElementById('error-container');
    const errorDiv = document.getElementById('error');
    const resultDiv = document.getElementById('result');
    const studentImage = document.getElementById('studentImage');
    const discountCode = document.getElementById('discount-code');
    const loader = document.getElementById('loader');
    const timerDiv = document.getElementById('timer');
    
    clearAll();
    
    if (registration.trim() === "") {
        showError("Please enter UDSM registration number.");
        return;
    }

    const regexPattern = /^\d{4}-\d{2}-\d{5}$/;
    if (!regexPattern.test(registration)) {
        showError("Invalid registration number format. Please use YYYY-NN-NNNNN.");
        return;
    }

    const imageUrl = `https://aris3.udsm.ac.tz/uploaded_files/student/photos/${registration}.jpg`;

    startTimer();
    loader.style.display = "block";
    timerDiv.style.display = "block";

    timeoutId = setTimeout(handleTimeout, 60000);

    const img = new Image();
    img.onload = () => handleImageLoad(imageUrl, registration);
    img.onerror = () => handleImageError();
    img.src = imageUrl;
}

function startTimer() {
    let seconds = 60;
    const timerDiv = document.getElementById('timer');
    timerDiv.textContent = seconds;

    timer = setInterval(() => {
        seconds--;
        timerDiv.textContent = seconds;
        if (seconds <= 0) {
            clearInterval(timer);
        }
    }, 1000);
}

function handleTimeout() {
    clearAll();
    showError("Network error couldn't fetch student details!");
}

function handleImageLoad(imageUrl, registration) {
    clearTimeout(timeoutId);
    clearInterval(timer);
    const studentImage = document.getElementById('studentImage');
    studentImage.src = imageUrl;
    generateDiscountCode(registration);
    showResult();
}

function handleImageError() {
    clearTimeout(timeoutId);
    clearInterval(timer);
    showError("Details not found for the given registration number.");
}

function generateDiscountCode(registration) {
    const discountCode = document.getElementById('discount-code');
    discountCode.textContent = `${registration}CV`;
}

function showResult() {
    const resultDiv = document.getElementById('result');
    const loader = document.getElementById('loader');
    const timerDiv = document.getElementById('timer');
    resultDiv.style.display = "block";
    loader.style.display = "none";
    timerDiv.style.display = "none";
}

function showError(message) {
    const errorContainer = document.getElementById('error-container');
    const errorDiv = document.getElementById('error');
    const loader = document.getElementById('loader');
    const timerDiv = document.getElementById('timer');
    errorDiv.textContent = message;
    errorContainer.style.display = "block";
    loader.style.display = "none";
    timerDiv.style.display = "none";
}

function clearAll() {
    const resultDiv = document.getElementById('result');
    const errorContainer = document.getElementById('error-container');
    const loader = document.getElementById('loader');
    const timerDiv = document.getElementById('timer');
    
    resultDiv.style.display = "none";
    errorContainer.style.display = "none";
    loader.style.display = "none";
    timerDiv.style.display = "none";
    
    document.getElementById('studentImage').src = "";
    document.getElementById('discount-code').textContent = "";
    document.getElementById('error').textContent = "";
    
    clearTimeout(timeoutId);
    clearInterval(timer);
}

// Add event listener to the verify button
document.getElementById('verify-btn').addEventListener('click', getStudentImage);