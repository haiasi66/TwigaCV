document.addEventListener('DOMContentLoaded', () => {
    let originalPrice = 3000;
    let currentPrice = 3000;
    let discountedPrice = 1500;
    let timer;

    const paymentForm = document.getElementById('paymentForm');
    const amountField = document.getElementById('amount');
    const orderTotalRows = document.querySelectorAll('.order-summary td strong');
    const applyDiscountBtn = document.querySelector('.apply-discount-btn');
    const payNowBtn = document.querySelector('.pay-now-btn');
    
    // --- Initial setup ---
    amountField.value = originalPrice;
    amountField.readOnly = true;
    updateOrderTotal(originalPrice);

    function updateOrderTotal(price) {
        orderTotalRows.forEach(row => {
            row.textContent = `TZS ${price.toLocaleString()}`;
        });
        amountField.value = price;
        currentPrice = price;
    }

    // --- Discount Logic ---
    applyDiscountBtn.addEventListener('click', verifyDiscount);

    function verifyDiscount() {
        const discountInput = document.getElementById('registration');
        const discountCode = discountInput.value.trim().toUpperCase();
        const errorContainer = document.getElementById('error-container');
        const loaderContainer = document.getElementById('loader-container');
        const resultDiv = document.getElementById('result');

        errorContainer.style.display = 'none';
        resultDiv.style.display = 'none';
        
        const regexPattern = /^\d{4}-\d{2}-\d{5}CV$/;
        if (!regexPattern.test(discountCode)) {
            showError('Invalid format. Please use YYYY-MM-NNNNNCV.');
            return;
        }

        const registrationNumber = discountCode.slice(0, -2);
        loaderContainer.style.display = 'block';

        checkImageExists(registrationNumber)
            .then(imageExists => {
                if (imageExists) {
                    updateOrderTotal(discountedPrice);
                    applyDiscountBtn.textContent = 'Applied';
                    applyDiscountBtn.disabled = true;
                    discountInput.disabled = true;
                    displayStudentImage(registrationNumber);
                    showSuccessMessage('Congratulations, 50% discount applied!');
                } else {
                    showError('Invalid discount code. Student details not found.');
                }
            })
            .catch(() => showError('An error occurred during verification.'))
            .finally(() => loaderContainer.style.display = 'none');
    }

    function checkImageExists(regNum) {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => resolve(true);
            img.onerror = () => resolve(false);
            img.src = `https://aris3.udsm.ac.tz/uploaded_files/student/photos/${regNum}.jpg`;
        });
    }

    function displayStudentImage(regNum) {
        document.getElementById('studentImage').src = `https://aris3.udsm.ac.tz/uploaded_files/student/photos/${regNum}.jpg`;
        document.getElementById('discount-code').textContent = `${regNum}CV`;
        document.getElementById('result').style.display = 'block';
    }

    // --- Payment Logic ---
    paymentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        if (validateForm()) {
            initiatePayment();
        }
    });

    async function initiatePayment() {
        payNowBtn.disabled = true;
        payNowBtn.textContent = 'INITIALIZING...';

        const formData = new FormData(paymentForm);

        try {
            const response = await fetch('php/initiate_payment.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                payNowBtn.textContent = 'AWAITING PAYMENT...';
                alert('Payment initiated. Please check your phone to complete the transaction.');
                pollForStatus(data.order_id);
            } else {
                alert(data.message || 'Payment initiation failed. Please try again.');
                payNowBtn.disabled = false;
                payNowBtn.textContent = 'Pay Now';
            }
        } catch (error) {
            console.error('Error:', error);
            alert('A network error occurred.');
            payNowBtn.disabled = false;
            payNowBtn.textContent = 'Pay Now';
        }
    }
    
    function pollForStatus(orderId) {
        let attempts = 0;
        const maxAttempts = 12; // Poll for 2 minutes (24 * 5s)
        
        const interval = setInterval(async () => {
            if(attempts >= maxAttempts) {
                clearInterval(interval);
                payNowBtn.textContent = 'Pay Now';
                payNowBtn.disabled = false;
                alert("Payment check timed out. Please check your email or contact support if you completed the payment.");
                return;
            }
            
            try {
                const response = await fetch(`php/check_status.php?order_id=${orderId}`);
                const data = await response.json();

                if(data.payment_status === "COMPLETED") {
    clearInterval(interval);
    // NEW: We are creating the expected filename and passing it to success.php
    const filename = `TwigaCV-${orderId}.pdf`;
    window.location.href = `success.php?order_id=${orderId}&filename=${encodeURIComponent(filename)}`;
}
                // If status is still PENDING, do nothing and let it poll again.
                 if(data.payment_status === "FAILED") {
                    clearInterval(interval);
                     payNowBtn.textContent = 'Pay Now';
                     payNowBtn.disabled = false;
                     alert("Payment failed. Please try again.");
                }
                
            } catch (error) {
                // Ignore single poll errors
                console.warn("Polling error: ", error);
            }
            attempts++;
        }, 5000); // Poll every 5 seconds
    }
    
    // --- UI & Validation ---
    function validateForm() {
        clearErrors();
        let isValid = true;
        
        const requiredFields = ['fullName', 'email', 'phone'];
        requiredFields.forEach(id => {
            const input = document.getElementById(id);
            if (!input.value.trim()) {
                showFieldError(input, `${input.labels[0].textContent.replace('*','').trim()} is required.`);
                isValid = false;
            }
        });

        const emailInput = document.getElementById('email');
        if (emailInput.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value)) {
            showFieldError(emailInput, 'Please enter a valid email address.');
            isValid = false;
        }

        const phoneInput = document.getElementById('phone');
        if (phoneInput.value && !/^(0\d{9}|255\d{9})$/.test(phoneInput.value)) {
            showFieldError(phoneInput, 'Phone must be 10 digits (e.g., 0712345678) or 12 digits (e.g., 255712345678).');
            isValid = false;
        }

        return isValid;
    }
    
    function showFieldError(field, message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'field-error';
        errorDiv.style.color = 'red';
        errorDiv.style.fontSize = '12px';
        errorDiv.style.marginTop = '5px';
        errorDiv.textContent = message;
        field.style.borderColor = 'red';
        field.parentElement.appendChild(errorDiv);
    }
    
    function clearErrors() {
        document.querySelectorAll('.field-error').forEach(e => e.remove());
        document.querySelectorAll('#paymentForm input').forEach(input => input.style.borderColor = '');
    }

    function showError(message) {
        const errorContainer = document.getElementById('error-container');
        const errorDiv = errorContainer.querySelector('#error');
        errorDiv.textContent = message;
        errorContainer.style.display = 'block';
    }

    function showSuccessMessage(message) {
        const resultDiv = document.getElementById('result');
        const successP = resultDiv.querySelector('.success-message');
        if (successP) successP.textContent = message;
        resultDiv.style.display = 'block';
    }
});