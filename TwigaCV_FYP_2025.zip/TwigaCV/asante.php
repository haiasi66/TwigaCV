<?php
session_start();

// Check if the user is allowed to see this page
if (!isset($_SESSION['cv_generated_successfully']) || !$_SESSION['cv_generated_successfully']) {
    // If not, redirect them to the form
    header('Location: swahili.html');
    exit();
}

// Unset the session variable so the page can't be refreshed/revisited
unset($_SESSION['cv_generated_successfully']);
?>
<!DOCTYPE html>
<html lang="sw" translate="no">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TwigaCV | Asante kwa Kuchagua TwigaCV</title>
  
  <meta name="robots" content="noindex, follow">

  <link rel="icon" type="image/png" href="img/favicon/favicon-32x32.png">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/landing-page.css" rel="stylesheet">
  <link href="font-awesome/css/fontawesome.min.css" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
</head>
<body>

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand topnav" href="index.html">TwigaCV</a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">Mwanzo</a></li>
                    <li><a href="services.html">Wasifu</a></li>
                    
                </ul>
            </div>
        </div>
    </nav>

    <div class="content-section-b">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h2 class="section-heading">Asante kwa Kuchagua TwigaCV!</h2>
                    <p class="lead">Wasifu wako umepakuliwa kwenye kifaa chako (angalia folda ya Downloads). Pia, tumekutumia nakala ya wasifu kwenye barua pepe uliyotoa. Tafadhali angalia kwenye (Inbox) au (Spam/Junk folder).</p>
                    <p class="lead">TwigaCV inajivunia kuwa sehemu ya safari yako ya ajira.</p>
                </div>
                <div class="col-lg-5 col-lg-offset-2 col-sm-6">
                    <img class="img-responsive" src="img/success.png" alt="Successful CV Creation">
                </div>
            </div>
        </div>
    </div>
    
    <div class="banner">
      <div class="container">
        <div class="row">
          <div class="col-lg-6"><h2>Karibu Tena!</h2></div>
          <div class="col-lg-6">
            <ul class="list-inline banner-social-buttons">
              <li><a href="index.html" class="btn btn-default btn-lg"><span class="network-name">Rudi Mwanzo</span></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p class="copyright text-muted small">Hakimiliki &copy; TwigaCV Tanzania <span id="currentYear"></span>. Haki Zote Zimehifadhiwa.</p>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Date JavaScript -->
    <script src="js/date.js"></script>
</body>
</html>